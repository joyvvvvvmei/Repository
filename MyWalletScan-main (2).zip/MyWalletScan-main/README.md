# MyWalletScan

## 关于

一款方便查看管理地址的工具

## 安装和使用

1. 运行:
```bash
git clone 
npm i
npm run dev
```

### 说明

```
1. 本项目纯前端，不涉及任何后端，所有数据均通过浏览器访问zkSync和stark官方接口获取，不会上传任何数据。
2. 本项目数据全部存放于浏览器本地的localStorage中，不会上传任何数据。
3. 如果有bug或者建议，欢迎提issue或者pr。
4. 本项目仅供学习交流使用，不提供任何形式的技术支持，使用本项目产生的任何后果与本人无关。
5. 大家卷起来吧！
```

## 使用

https://bitboxtools.github.io/



