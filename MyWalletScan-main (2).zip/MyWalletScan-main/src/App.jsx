import WrapperRouter from "@routes";

function App() {
    return (
        <div className="App">
            <WrapperRouter/>
        </div>
    )
}

export default App;
